<?php
/**
 * Created by PhpStorm.
 * User: zhongwen
 * Date: 1/21/17
 * Time: 15:45
 */

$singer1 = htmlentities($_REQUEST["singer1"]);
$singer2 = htmlentities($_REQUEST["singer2"]);

if(empty($singer1) || empty($singer2)){
    $returnArray["status"] = "400";
    $returnArray["message"] = "Missing required information";
    echo json_encode($returnArray);
    return;
}

$file = parse_ini_file("/Applications/XAMPP/citpennapps.ini");

$host = trim($file["dbhost"]);
$user = trim($file["dbuser"]);
$pass = trim($file["dbpass"]);
$name = trim($file["dbname"]);

require ("index.php");

$access = new access($host, $user, $pass, $name);
$access->connect();

$result["singer1"] = $access->singerInfo($singer1);
//$temp = "Xiang Zhang";
//echo json_encode($access->singerInfo($temp));
$result["singer2"] = $access->singerInfo($singer2);

if($result["singer1"] && $result["singer2"]){
    $returnArray["status"] = "200";
    $returnArray["message"] = "Succeed";
    $returnArray["name1"] = $result["singer1"]["name"];
    $returnArray["name2"] = $result["singer2"]["name"];
}else{
    $returnArray["status"] = "400";
    $returnArray["message"] = "Could not get the singer info";
}
//
//if($result){
//    $singerinfo = $access->singerInfo(singer1);
//
//}else{
//    $returnArray["status"] = "400";
//    $returnArray["message"] = "Could not get the info of the singer";
//}

echo json_encode($returnArray);


$access->disconnect();

?>