<?php

// Declare class to access this php file
class access {
    var $host = null;
    var $user = null;
    var $pass = null;
    var $name = null;
    var $conn = null;
    var $result = null;

    // constructing class
    function __construct($dbhost, $dbuser, $dbpass, $dbname) {
        $this->host = $dbhost;
        $this->user = $dbuser;
        $this->pass = $dbpass;
        $this->name = $dbname;
    }

    // connection function
    public function connect(){
        // etsablish connection and store it in $conn
        $this->conn = new mysqli($this->host, $this->user, $this->pass, $this->name);

        // if error
        if(mysqli_connect_error()){
            echo 'Could not connect to database';
        }

        $this->conn->set_charset("utf8");
    }

    // disconnection function
    public function disconnect(){
        if($this->conn != null) {
            $this->conn->close();
        }
    }

    public function singerInfo($singer1){
        $sql = "SELECT * FROM singers WHERE name = '".$singer1."'";

        $result = $this->conn->query($sql);

        $returnArray = null;

        if($result != null && (mysqli_num_rows($result) >= 1)){
            $row = $result->fetch_array(MYSQLI_ASSOC);

            if(!empty($row)){
                $returnArray = $row;
            }
        }

        return $returnArray;
    }
}

?>