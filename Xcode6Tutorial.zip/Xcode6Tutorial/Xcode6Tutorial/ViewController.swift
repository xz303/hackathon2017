//
//  ViewController.swift
//  Xcode6Tutorial
//
//  Created by Zhong Wen on 1/20/17.
//  Copyright © 2017 Wen Zhong. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var singer1: UITextField!
    @IBOutlet weak var singer2: UITextField!
    @IBOutlet weak var submit: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func submitSingers(_ sender: Any) {
        if(singer1.text!.isEmpty || singer2.text!.isEmpty){
            singer1.attributedPlaceholder = NSAttributedString(string:"Taylor Swift", attributes:[NSForegroundColorAttributeName:UIColor.red])
            singer2.attributedPlaceholder = NSAttributedString(string:"Adele", attributes:[NSForegroundColorAttributeName:UIColor.red])
        }else{
            let url = NSURL(string:"localhost:63342/untitled/input.php")!
//            let request = NSMutableURLRequest(URL:url)
            var request = URLRequest(url:URL(string:"http://www.example.com/connect-add.php")!)
            request.HTTPMethod = "POST"
            let body = "singer1=\(singer1.text!)&singer2=\(singer2.text)"
            request.HTTPBody = body
            
            URLSession.sharedSession().dataTaskWithRequest(request, completionHandler:{(data:NSData?, response: URLResponse?, error:NSError?) in
                if error == nil{
                    dispatch_async(dispatch_get_main_queue(),{
                        do{
                            let json = try NSJSONSerialization.JSONObjectWithData(data!, options:.MutableContainers) as? NSDictionary
                            
                            guard let parseJSON = json else {
                                print("Error while parsing")
                                return
                            }
                            
                            let id = parseJSON("id")
                            
                            if id != nil{
                                print(parseJSON)
                            }
                        }catch{
                            print("Caught an error: \(error)")
                        }
                    })
                }else{
                    print("error:\(error)")
                }
            })
        }
    }
}

